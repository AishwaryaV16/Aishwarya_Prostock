function cat(data)
{
    localStorage.setItem("cat_id",data);
    window.location='product.html';

 }




