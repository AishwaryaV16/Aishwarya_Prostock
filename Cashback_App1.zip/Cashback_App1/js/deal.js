function deal() 
			{
				window.open("deal-of-the-day.html","_self");
			}