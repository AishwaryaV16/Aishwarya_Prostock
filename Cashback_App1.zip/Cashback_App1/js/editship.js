function editship(data)
{
    localStorage.setItem("shipping_id",data);
    window.location='shipping-address.html';

 }




