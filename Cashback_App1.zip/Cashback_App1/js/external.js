function external_p(data)
{
    localStorage.setItem("cat_id",data);
    location.href='external-product.html';
 }




