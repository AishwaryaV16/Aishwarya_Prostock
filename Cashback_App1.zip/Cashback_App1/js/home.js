function home() 
			{
				window.open("yoneak.html","_self");
			}