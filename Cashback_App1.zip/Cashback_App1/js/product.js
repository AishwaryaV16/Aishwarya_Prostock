function product(data)
{
    localStorage.setItem("pro_id",data);
    window.location='product-details.html';

 }




