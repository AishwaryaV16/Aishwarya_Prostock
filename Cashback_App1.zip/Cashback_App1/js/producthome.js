function producthome() 
			{
				window.open("product.html","_self");
			}