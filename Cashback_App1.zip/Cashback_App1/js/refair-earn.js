function refairEarn()
{
    
    window.location='Refair-Earn.html';

 }




