function shipping(data)
{
    localStorage.setItem("shipping_id",data);
    window.location='checkout.html';

 }




