function Store(data)
{
    localStorage.setItem("id",data);
    window.location='store-details.html';

 }




