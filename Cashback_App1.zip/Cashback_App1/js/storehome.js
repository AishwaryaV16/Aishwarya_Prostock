function storehome() 
			{
				window.open("store.html","_self");
			}