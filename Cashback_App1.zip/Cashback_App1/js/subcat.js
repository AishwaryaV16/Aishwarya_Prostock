function subcat(data)
{
    localStorage.setItem("sub_cat_id",data);
    window.location='product.html';

 }




