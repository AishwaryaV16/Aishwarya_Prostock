function walletdetail() 
			{
				window.open("wallet-details.html","_self");
			}